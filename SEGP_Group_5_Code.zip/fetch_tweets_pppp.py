from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import time

CONSUMER_KEY = "s9zfXzH4ys2UmxVf7qwHefSXo"
CONSUMER_SECRET = "aPaqNrHZa0hgkamB3EGapQFHXZwtPsqQuOYVfWfwlwRDAQWQ2E"
ACCESS_TOKEN ="4543869137-nS45taUqUnBW285Eq1py6znAsyT1tfWx1Mhm6ll"
ACCESS_TOKEN_SECRET = "PE31HhmXGz5JvY2hv0hNEGsxzbi4meLG1dD9ULFGW3opC"

class listener(StreamListener):

    def on_data(self, data):
        try:
            print (data)
            saveFile = open('pppppp.json', 'a')
            saveFile.write(data)
            saveFile.write('\n')
            saveFile.close()
            return True

        except Exception as e:
            print ('failed ondata,', str(e))
            time.sleep(5)
            pass

    def on_error(self, status):
        print (status)
        if status == 420:
            return False


if __name__ == '__main__':
    auth = OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
    stream = Stream(auth, listener())

    keywords = ['MediaCellPPP','AAliZardari','ppp_org','BBhuttoZardari','ppp___official']
    stream.filter(track=keywords)