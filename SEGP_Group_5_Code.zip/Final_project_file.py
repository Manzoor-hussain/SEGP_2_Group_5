#Import the necessary methods from tweepy library
from textblob import TextBlob
import tweepy
from tweepy.streaming import StreamListener
from fastnumbers import fast_real
from matplotlib import pyplot as plt
from tweepy import OAuthHandler
from tweepy import Stream
import json
import twitter
import pandas as pd
import matplotlib.pyplot as plt
import re

###SENTIMENT_ANALYSIS
###PTI
##POSITIVE COUNTER
pos_count_pti = 0
pos_correct_pti = 0
tweets_data=[]
tweets_file = open("hd.json", "r")
for line in tweets_file:
    try:
        tweet = json.loads(line)
        tweets_data.append(tweet)
    except:
        continue

day=""
month=""
for key in tweets_data:
    text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    #Sentiment analysis
    analysis = TextBlob(text)
    splt = key['created_at'].split(' ')
    day = splt[2]
    month = splt[1]
    if analysis.sentiment.polarity > 0:
        pos_correct_pti += 1
    pos_count_pti +=1


neg_count_pti = 0
neg_correct_pti = 0
###
##NeGATIVE_COUNTER

for key in tweets_data:
    text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    analysis = TextBlob(text)
    splt=key['created_at'].split(' ')
    day=splt[2]
    month=splt[1]
    if analysis.sentiment.polarity <=0:
        neg_correct_pti += 1
    neg_count_pti +=1
###
###
###
###SAVING Output Percentages

file= open("output_pti.txt", "a",encoding='utf-8')
print("Positive accuracy = {}% via {} samples".format(pos_correct_pti/pos_count_pti*100.0, pos_count_pti))
file.write(str(pos_correct_pti/pos_count_pti*100.0)+",")
file.write(str(day)+"\n")
file.close()

###




###PPPP

pos_count_pppp = 0
pos_correct_pppp = 0
tweets_data_pppp=[]
tweets_file_pppp = open("pppppp.json", "r")
for line in tweets_file_pppp:
    try:
         tweet_pppp = json.loads(line)
         tweets_data_pppp.append(tweet_pppp)
    except:
         continue

day_pppp=""
month_pppp=""

for key in tweets_data_pppp:
    text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    analysis = TextBlob(text)
    splt = key['created_at'].split(' ')
    day_pppp = splt[2]
    month_pppp = splt[1]
    if analysis.sentiment.polarity > 0:
        pos_correct_pppp += 1
    pos_count_pppp +=1


neg_count_pppp = 0
neg_correct_pppp = 0
###
##NeGATIVE_COUNTER

for key in tweets_data_pppp:
    text=re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    analysis = TextBlob(text)
    splt=key['created_at'].split(' ')
    day_pppp=splt[2]
    month_pppp=splt[1]
    if analysis.sentiment.polarity <=0:
       neg_correct_pppp += 1
    neg_count_pppp +=1

### Saving output to file
file= open("output_pppp.txt", "a",encoding='utf-8')
print("Positive accuracy = {}% via {} samples".format(pos_correct_pppp/pos_count_pppp*100.0, pos_count_pppp))
file.write(str(pos_correct_pppp/pos_count_pppp*100.0)+",")
file.write(str(day_pppp)+"\n")
file.close()

###

###PMLN

pos_count_pmln = 0
pos_correct_pmln = 0
tweets_data_pmln=[]
tweets_file_pmln = open("pmlnn.json", "r")

for line in tweets_file_pmln:
    try:
         tweet_pmln = json.loads(line)
         tweets_data_pmln.append(tweet_pmln)
    except:
         continue

day_pmln=""
month_pmln=""

for key in tweets_data_pmln:
    text = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    analysis = TextBlob(text)
    splt = key['created_at'].split(' ')
    day_pmln = splt[2]
    month_pmln = splt[1]
    if analysis.sentiment.polarity > 0:
        pos_correct_pmln += 1
    pos_count_pmln +=1


neg_count_pmln = 0
neg_correct_pmln = 0
###
##NeGATIVE_COUNTER

for key in tweets_data:
    text=re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', key['text'], flags=re.MULTILINE)
    analysis = TextBlob(text)
    splt=key['created_at'].split(' ')
    day_pmln=splt[2]
    month_pmln=splt[1]
    if analysis.sentiment.polarity <=0:
       neg_correct_pmln += 1
    neg_count_pmln +=1

###SAVING OUTPUT TO FILE
file= open("output_pmln.txt", "a",encoding='utf-8')
print("Positive accuracy = {}% via {} samples".format(pos_correct_pmln/pos_count_pmln*100.0, pos_count_pmln))
file.write(str(pos_correct_pmln/pos_count_pmln*100.0)+",")
file.write(str(day_pmln)+"\n")
file.close()
###

### Graphing....
###PTI
xaxis_pti=[]
yaxis_pti=[]
with open("output_pti.txt","r",encoding='utf-8') as f:
    for line in f.read().split('\n'):
        arr = line.split(',')
        if(len(arr)!=1):
            xaxis_pti.append(fast_real(arr[0]))
            yaxis_pti.append(fast_real(arr[1]))
    f.close()
####
###PPPP
xaxis_pppp=[]
yaxis_pppp=[]
with open("output_pppp.txt","r",encoding='utf-8') as f:
    for line in f.read().split('\n'):
        arr = line.split(',')
        if(len(arr)!=1):
            xaxis_pppp.append(fast_real(arr[0]))
            yaxis_pppp.append(fast_real(arr[1]))
    f.close()
###
###PMLN
xaxis_pmln=[]
yaxis_pmln=[]
with open("output_pmln.txt","r",encoding='utf-8') as f:
    for line in f.read().split('\n'):
        arr = line.split(',')
        if(len(arr)!=1):
            xaxis_pmln.append(fast_real(arr[0]))
            yaxis_pmln.append(fast_real(arr[1]))
    f.close()
###

plt.figure("SENTIMENT_ANALYSIS")
plt.title("PTI    PMLN     PPPP")
if (month_pppp=='Mar'):
    plt.xlabel("March")
elif(month_pppp=='Apr'):
    plt.xlabel("April")
plt.ylabel("Positivity")
plt.gca().set_xlim(left=0)
plt.gca().set_xlim(right=30)
plt.plot(yaxis_pti,xaxis_pti,label='pti')
plt.plot(yaxis_pmln,xaxis_pmln,label='pmln')
plt.plot(yaxis_pppp,xaxis_pppp,label='pppp')
plt.tight_layout()
plt.legend()
plt.show()
